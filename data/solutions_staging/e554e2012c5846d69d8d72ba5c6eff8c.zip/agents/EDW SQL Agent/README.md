# Agent Export: EDW SQL Agent

                            ## Export Information
                            - **Export Date**: 2026-04-21T10:09:51.055525
                            - **Agent ID**: 139
                            - **Platform Version**: 1.7

                            ## Contents
                            - `/metadata.json` - Complete agent configuration
                            - `/custom_tools/` - Custom tool implementations (0 tools)
                            - `/knowledge/` - Agent knowledge base (0 items)
                            - `/knowledge/documents/` - Exported documents (0 documents)
                            - `/environment/` - Python environment configuration
                            

                            ## Tools Summary
                            ### Core Tools (0)
                            

                            ### Custom Tools (0)
                            

                            ## Import Instructions
                            1. Use the Import Agent feature in the platform
                            2. Select this ZIP file
                            3. The system will create a new agent with all configurations
                            4. If an environment is included, you can choose to create or skip it

                            ## Notes
                            - Custom tools will be imported if they don't already exist
                            - Knowledge documents can be re-imported or linked to existing documents
                            - Core tool dependencies will be automatically resolved
                            - Environment packages will be installed automatically if environment is created
                            