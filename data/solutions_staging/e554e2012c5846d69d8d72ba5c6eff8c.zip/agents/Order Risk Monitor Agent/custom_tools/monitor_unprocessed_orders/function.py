@tool
def monitor_unprocessed_orders() -> str:
    """Queries unprocessed orders from OMS."""
    import json
    import pyodbc
    
    try:
        # Set connection string
        conn_string = '{CONN:ERPDB}'
        conn = pyodbc.connect(conn_string)
        cursor = conn.cursor()
    
        # Get all eligible orders from main OMS
        cursor.execute("SELECT order_id, customer_name, order_total, customer_type, estimated_delivery_date, lead_time_days, requires_approval, getdate() [current_date] FROM orders WHERE current_status not in ('Shipped','Processing')")
        oms_orders = cursor.fetchall()
    
        if not oms_orders:
            return json.dumps({"message": "No eligible orders found in OMS system"})
    
        results = []
    
        for oms_order in oms_orders:
            order_id, customer_name, order_total, customer_type, estimated_delivery_date, lead_time_days, requires_approval, current_date = oms_order
            
            # Check if order exists in ERP
            cursor.execute("SELECT erp_internal_id, order_status FROM erp_orders WHERE source_order_id = ?", order_id)
            erp_record = cursor.fetchone()
    
            # Check if order exists in WMS  
            cursor.execute("SELECT wms_internal_id, picking_status FROM wms_orders WHERE source_order_id = ?", order_id)
            wms_record = cursor.fetchone()
    
    
            # Append order to results
            result = {
                "order_id": order_id,
                "customer_name": customer_name,
                "order_total": order_total,
                "customer_type": customer_type,
                "current_date": current_date,
                "estimated_delivery_date": estimated_delivery_date,
                "lead_time_days": lead_time_days,
                "requires_approval": requires_approval,
                "erp_record": {"exists": bool(erp_record), "internal_id": erp_record[0] if erp_record else None},
                "wms_record": {"exists": bool(wms_record), "internal_id": wms_record[0] if wms_record else None}
            }
            results.append(result)
            
        return json.dumps(results, default=str)
    
    except Exception as e:
        return f"Error monitoring orders: {str(e)}"
    
